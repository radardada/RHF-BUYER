document.getElementById("vip-box").innerHTML =
  "VIP aktif selama 1 hari. Harga: 100K";