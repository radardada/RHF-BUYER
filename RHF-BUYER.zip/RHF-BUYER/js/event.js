fetch("config.json")
  .then(r => r.json())
  .then(data => {
    let box = document.getElementById("event-container");

    if (data.events.length === 0) {
      box.innerHTML = "Belum ada event.";
      return;
    }

    box.innerHTML = "";
    data.events.reverse().forEach(event => {
      box.innerHTML += `
        <div class="card">
          <h3>${event.title}</h3>
          <p>${event.description}</p>
        </div>
      `;
    });
  });