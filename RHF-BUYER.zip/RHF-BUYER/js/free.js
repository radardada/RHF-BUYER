document.getElementById("free-box").innerHTML =
  "Akses FREE aktif!";